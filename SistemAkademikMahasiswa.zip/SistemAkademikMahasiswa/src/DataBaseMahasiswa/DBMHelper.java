/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBaseMahasiswa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author imran sukron hamid
 */
public class DBMHelper {
    private static final String USERNAME="root";
    private static final String PASSWORD="";
    private static final String DB="universitaskonoha";
    private static final String MYCONN = "jdbc:mysql://localhost/"+DB;
    public static Connection getConnection(){
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(MYCONN,USERNAME,PASSWORD);
            JOptionPane.showMessageDialog(null, "Berhasil Terhubung");
        } catch (SQLException ex) {
            Logger.getLogger(DBMHelper.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Gagal Terhubung");
        }
        return conn;
    }
}
